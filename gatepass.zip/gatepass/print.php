<?php
    include 'connectDB.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report</title>
</head>
<body>
    <h2>SANJIVANI COLLEGE OF ENGINEERING, KOPARGAON</h2>
    <h3>Gate Pass</h3>

    <?php
        $data=$_GET['data'];
        $sql= "SELECT * FROM `logs` WHERE id=$data";
        $result=mysqli_query($conn,$sql);
        if($result)
        {
            ?><h4>
            <?php
            $row=mysqli_fetch_assoc($result);
            echo '<div class="container">
                    Gate Pass No.- '.$row['id'].'<br>
                    Name- '.$row['Name'].'<br>
                    Department- '.$row['Department'].'<br>
                    Reason Type- '.$row['Personal'].'<br>
                    Reason- '.$row['Reason'].'<br>
                    Time Out- '.$row['TimeOut'].'<br>
                    Time In- '.$row['TimeIn'].'<br>
                    HOD- <button><img src="image/che.png" width="25"></button>

                </div>

                ';
                ?>
                </h4>
                <?php
        }
    ?>

</body>
</html>