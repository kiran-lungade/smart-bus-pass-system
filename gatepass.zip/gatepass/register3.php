<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<title>Registration Page</title>
	<!-- <link rel="stylesheet" href="./login.css"> -->
<style type="text/css">
body {
    background-image:url("image/sanjivani.jpg");background-repeat:no-repeat;background-attachment:fixed;
    background-position: top right;background-size: cover;
    height: 85vh;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: sans-serif;
}
.Abc{ 
    background-color:#ddd; 
    opacity: 0.8;
    display: flex;
    align-items: center;
    flex-direction: column;
    height: 60vh;
    width: 50vh;
    border: 4px solid gray;
    border-radius: 12px;
    text-align: center;
    margin-top: 10%;
    box-shadow: 10px 12px 18px gray;
}          
header {
    height: 1px;
    padding-top: 0px;
    padding-bottom: 80px;
    font-size: 28px;
    font-weight: 700;
    color: navy;
    font-family: 'Times New Roman', Times, serif;
}
h2{
    padding: 7px;
    padding-bottom: 0%;
    font-family: 'Times New Roman';
    font-size:30px;
	color: black;
}
.info{
    text-align: center;
    text-transform: capitalize;
    margin: 40px;
}
.info-1{
    text-align: center;
    text-transform: capitalize;
}
label{
    text-transform: capitalize;
    font-size: 22px;
    color: rgb(255, 255, 0);
}
input{
    text-align: center;
    text-transform: capitalize;
    border: 2px solid black;
    border-radius: 35px;
    height: 45px;
    width: 280px;
    font-size: 20px;
    font-family: cursive;
    background-color: whitesmoke;
    color: solid black;
    margin-top: 5%;
    
}
input:hover{
    background-color: #b4e072;
    color: #12026d;
    transform: scale(1.18);
    transition: transform 200ms ease-in;
}
button{
    margin: 35px;
    margin-top: 5px;
    border: 1px solid black;
    border-radius: 8px;
    width: 80px;
    text-align: center;
    text-transform: capitalize;
	background: rgb(252,205,128);
    background: linear-gradient(90deg, rgba(252,205,128,1) 0%, rgba(209,122,142,1) 55%, rgba(220,159,174,1) 100%);
    font-size: 20px;
    font-weight: 375;
    font-family: cursive;
	

        /* margin-top: 7%;
        display: block;
        padding: 10px;
        border: 0;
        color: #fff;
        border-radius: 20px;
        cursor: pointer;
        font-size: 20px;
        font-family: cursive;
        background: rgb(252,205,128);
        background: linear-gradient(90deg, rgba(252,205,128,1) 0%, rgba(209,122,142,1) 55%, rgba(220,159,174,1) 100%);  */
        
    }
button:focus{
        outline: 0;
}
button:hover{
        opacity: 0.8;
        transition: .3s;
    } 
</style>
</head>
<body scroll="no" style="overflow : hidden">

<section>
	<Center>

     
	<h1>Sanjivani RFID</h1>
     	<h2><center>Registration Page</center></h1>
     	<hr>
	

     	<form name = "f2" method="post">
	<center>
				<input type="text" name="name" id="name" placeholder="Name" required />
				<br/><br/>

				<input type="text" name="Department" id="Department" placeholder="Department" required/>
				<br/><br/>

				<input type="text" name="username" id="username" placeholder="Username" required/>
				<br/><br/>

				<input type="password" name="password" id="password" placeholder="Password" required/>
				<br/><br/>

				<input type="password" name="re-password" id="re-password" placeholder="Confirm Password" required/>
				<br/><br/>

				<button type="submit" id="register-btn" onclick="validation()">Submit</button>
				<a href = "login3.php"><button type="button" id="btn" />Login</button></a>
			</center>
			</form>
     </div>
	


	 <script>  
                function validation()  
                {  
                    var name=document.f2.name.value;  
                    var Department=document.f2.mobile.value; 
					var username=document.f2.username.value;
					var password=document.f2.password.value;
					var repass=document.f2.re-password.value;
					 
                    if(name.length=="" && Department.length=="" && username.length=="" && password.length=="" && repass.length=="" && password!=repass) {  
                        alert("Fields are empty or password doesnt match");  
                        return false;  
                    }  
                    else  
                    {  
                    }
				}                             
                
            </script> 

    </div>
</section>

<?php
error_reporting(0);
// servername => localhost
// username => root
// password => empty
// database name => staff
$conn = mysqli_connect("localhost", "root", "", "nodemcugate");
 
// Check connection
if($conn === false){
	die("ERROR: Could not connect. "
		. mysqli_connect_error());
}
 
// Taking all 5 values from the form data(input)
$name =  $_REQUEST['name'];
$Department = $_REQUEST['Department'];
$username =  $_REQUEST['username'];
$password = $_REQUEST['password'];
$confirm_password = $_REQUEST['re-password'];
// Performing insert query execution
// here our table name is college

if($password==$confirm_password)
{
	$sql = "INSERT INTO registration3 VALUES ('$name',
	'$Department','$username','$password')";

	if(mysqli_query($conn, $sql)){

	//echo nl2br("\n$first_name\n $last_name\n "
		//. "$gender\n $address\n $email");
	} 
	else
	{
		echo "ERROR: Hush! Sorry $sql. "
		. mysqli_error($conn);
	}
}
else
{
	echo '<script>alert("Password does not match")</script>';
}
 
// Close connection
mysqli_close($conn);
?>
	
</body>
</html>

