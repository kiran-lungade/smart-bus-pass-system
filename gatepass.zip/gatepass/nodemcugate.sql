-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2023 at 04:34 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nodemcugate`
--

-- --------------------------------------------------------

--
-- Table structure for table `approval`
--

CREATE TABLE `approval` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `SerialNumber` int(11) DEFAULT NULL,
  `Department` varchar(30) NOT NULL,
  `CardID` double NOT NULL,
  `Date` date NOT NULL DEFAULT current_timestamp(),
  `Reason` varchar(50) NOT NULL,
  `Approval` varchar(20) NOT NULL DEFAULT 'Requested'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `approval`
--

INSERT INTO `approval` (`id`, `username`, `SerialNumber`, `Department`, `CardID`, `Date`, `Reason`, `Approval`) VALUES
(1, 'Piyush Shinde', 56, 'IT', 928917125, '2023-04-02', 'Sick Leave', 'Approved'),
(2, 'Arati Rahane', 47, 'IT', 9220967127, '2023-04-02', 'Demo', 'Rejected'),
(3, 'Shital Rahane', 49, 'Computer', 1222058773, '2023-04-02', 'Doctor', 'Approved'),
(4, 'Kiran Lungade', 39, 'IT', 14011844127, '2023-04-02', 'Sick Leave', 'Rejected'),
(5, 'Vaishnavi Aher', 65, 'Computer', 20412311125, '2023-04-03', 'Demo', 'Rejected'),
(6, 'Piyush Shinde', 56, 'IT', 928917125, '2023-04-04', 'Bank', 'Approved'),
(7, 'Shital Rahane', 49, 'IT', 1084640127, '2023-04-05', 'Home', 'Approved'),
(8, 'Kiran Lungade', 39, 'IT', 14011844127, '2023-04-05', 'Home', 'Rejected'),
(9, 'Piyush Shinde', 56, 'IT', 928917125, '2023-04-05', 'Sick', 'Approved'),
(10, 'Arati Rahane', 47, 'IT', 9220967127, '2023-04-05', 'Bus', 'Rejected'),
(11, 'Shreyas Bhor', 7, 'IT', 25210948127, '2023-04-06', 'Sick', 'Approved'),
(13, 'Piyush Shinde', 56, 'IT', 928917125, '2023-04-06', 'Bank', 'Rejected'),
(14, 'Piyush Shinde', 56, 'IT', 928917125, '2023-04-08', 'Home', 'Approved'),
(15, 'Arati Rahane', 47, 'IT', 9220967127, '2023-04-08', 'Sick', 'Approved'),
(16, 'Piyush Shinde', 56, 'IT', 928917125, '2023-04-11', 'Sick', 'Approved'),
(17, 'Arati Rahane', 47, 'IT', 9220967127, '2023-04-11', 'Bank', 'Approved'),
(18, 'Piyush Shinde', 56, 'IT', 928917125, '2023-04-12', 'Bank', 'Approved'),
(19, 'Piyush Shinde', 56, 'IT', 928917125, '2023-04-12', 'Bus', 'Approved'),
(20, 'Piyush Shinde', 56, 'IT', 928917125, '2023-04-12', 'Bank', 'Approved'),
(21, 'Kiran Lungade', 39, 'IT', 14011844127, '2023-04-12', 'Home', 'Approved'),
(22, 'Kiran Lungade', 39, 'IT', 14011844127, '2023-04-12', 'Bank', 'Rejected'),
(23, 'Kiran Lungade', 39, 'IT', 14011844127, '2023-04-12', 'Bank', 'Rejected'),
(25, 'Piyush Shinde', 56, 'IT', 928917125, '2023-04-13', 'Home', 'Approved'),
(27, 'Kiran Lungade', 39, 'IT', 14011844127, '2023-04-13', 'Bank', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `CardNumber` double DEFAULT NULL,
  `Name` varchar(30) DEFAULT NULL,
  `SerialNumber` double DEFAULT NULL,
  `Department` varchar(30) NOT NULL,
  `Reason` varchar(50) NOT NULL,
  `DateLog` date DEFAULT NULL,
  `TimeIn` time DEFAULT NULL,
  `TimeOut` time DEFAULT NULL,
  `UserStat` varchar(100) NOT NULL,
  `building_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `CardNumber`, `Name`, `SerialNumber`, `Department`, `Reason`, `DateLog`, `TimeIn`, `TimeOut`, `UserStat`, `building_number`) VALUES
(1, 14011844127, 'Kiran Lungade', 39, 'IT', '0', '2022-12-01', '13:08:28', '14:27:42', 'Arrived late and Left early', 0),
(2, 928917125, 'Piyush Shinde', 56, 'IT', '0', '2022-12-01', '13:09:18', '14:27:43', 'Arrived late and Left early', 0),
(3, 762533125, 'Pramila Shinde', 57, 'IT', '0', '2022-12-01', '13:11:28', '13:11:32', 'Arrived late and Left early', 0),
(4, 1084640127, 'Shital Rahane', 49, 'IT', '0', '2022-12-01', '13:49:00', '13:49:03', 'Arrived late and Left early', 0),
(5, 928917125, 'Piyush Shinde', 56, 'IT', '0', '2022-12-02', '20:50:03', '20:52:38', 'Arrived late and Left on time', 0),
(6, 928917125, 'Piyush Shinde', 0, 'IT', '0', '2022-12-03', '09:47:49', '12:04:15', 'Arrived on time and Left early', 0),
(7, 18814114125, 'Ishwar Wagh', 0, 'IT', '0', '2022-12-03', '09:52:12', '09:52:14', 'Arrived on time and Left early', 0),
(8, 14011844127, 'Kiran Lungade', 0, 'IT', '0', '2022-12-03', '09:58:45', '11:39:38', 'Arrived on time and Left early', 0),
(9, 1084640127, 'Shital Rahane', 0, 'IT', '0', '2022-12-03', '10:08:34', '11:39:44', 'Arrived late and Left early', 0),
(10, 9220967127, 'Arati Rahane', 0, 'IT', '0', '2022-12-03', '10:37:39', '10:38:27', 'Arrived late and Left early', 0),
(11, 10857250123, 'Viraj Adhav', 0, 'IT', '0', '2022-12-03', '10:41:59', '10:42:30', 'Arrived late and Left early', 0),
(12, 25210948127, 'shreyas bhor', 0, 'IT', '0', '2022-12-03', '10:47:40', NULL, 'Arrived late', 0),
(13, 442399125, 'Dipjyot jape', 0, 'IT', '0', '2022-12-03', '11:20:57', NULL, 'Arrived late', 0),
(14, 23613252127, 'Vaishavi Dhavade', 0, 'IT', '0', '2022-12-03', '11:49:31', '11:49:50', 'Arrived late and Left early', 0),
(15, 12415613125, 'Arati Walte', 0, 'IT', '0', '2022-12-03', '11:58:13', '11:58:20', 'Arrived late and Left early', 0),
(16, 10823810125, 'Jayavant Warkhade', 0, 'IT', '0', '2022-12-03', '12:03:20', '12:03:22', 'Arrived late and Left early', 0),
(17, 10812311125, 'tejas sonawane', 0, 'IT', '0', '2022-12-03', '12:05:25', '12:05:42', 'Arrived late and Left early', 0),
(18, 928917125, 'Piyush Shinde', 0, 'IT', '0', '2023-01-09', '14:27:06', '15:20:02', 'Arrived late', 0),
(19, 14011844127, 'Kiran Lungade', 0, 'IT', '0', '2023-01-12', '14:27:33', '14:27:38', 'Arrived late and Left early', 0),
(20, 145208110224, 'Vishal Gavade', 0, 'IT', '0', '2023-01-12', '14:28:36', NULL, 'Arrived late', 0),
(21, 1084640127, 'Shital Rahane', 0, 'IT', '0', '2023-01-12', '15:02:24', '16:01:16', 'Arrived late and Left early', 0),
(22, 10857250123, 'Viraj Adhav', 0, 'IT', '0', '2023-01-12', '15:17:29', '15:17:32', 'Arrived late and Left early', 0),
(23, 928917125, 'Piyush Shinde', 0, 'IT', '0', '2023-01-12', '15:52:25', '16:13:28', 'Arrived late and Left early', 0),
(24, 762533125, 'Pramila Shinde', 0, 'IT', '0', '2023-01-12', '16:13:50', '16:13:52', 'Arrived late and Left early', 0),
(25, 23613252127, 'Vaishavi Dhavade', 0, 'IT', '0', '2023-01-12', '16:15:12', '16:15:14', 'Arrived late and Left early', 0),
(26, 14011844127, 'Kiran Lungade', 0, '39', '0', '2023-01-13', '09:10:47', '09:10:50', 'Arrived on time and Left early', 0),
(27, 765610125, 'Vaibhav Lokhande', 0, '38', '0', '2023-01-13', '09:20:22', '11:17:12', 'Arrived on time and Left early', 0),
(28, 281938125, 'Tejas Nagare', 0, '41', '0', '2023-01-13', '09:57:23', '09:58:02', 'Arrived on time and Left early', 0),
(29, 20412311125, 'Aher Vaishnavi', 0, '65', '0', '2023-01-13', '09:59:36', NULL, 'Arrived on time', 0),
(30, 1402208125, 'Shubham Kamandar', 0, '32', '0', '2023-01-13', '10:00:56', '10:22:47', 'Arrived late and Left early', 0),
(31, 928917125, 'Piyush Shinde', 0, '56', '0', '2023-01-13', '10:04:43', '11:23:36', 'Arrived late and Left early', 0),
(32, 204910124, 'Saurabh hon', 0, '26', '0', '2023-01-13', '10:06:18', NULL, 'Arrived late', 0),
(33, 1222058773, 'Sachin Jagtap', 0, '36', '0', '2023-01-13', '10:09:15', NULL, 'Arrived late', 0),
(34, 10857250123, 'Viraj Adhav', 0, '1', '0', '2023-01-13', '10:12:05', '10:12:18', 'Arrived late and Left early', 0),
(35, 25210948127, 'shreyas bhor', 0, '7', '0', '2023-01-13', '10:18:21', NULL, 'Arrived late', 0),
(36, 10823810125, 'Jayavant Warkhade', 0, '69', '0', '2023-01-13', '10:18:30', NULL, 'Arrived late', 0),
(37, 1084640127, 'Shital Rahane', 0, '49', '0', '2023-01-13', '10:56:54', '10:57:13', 'Arrived late and Left early', 0),
(38, 928917125, 'Piyush Shinde', 0, '56', '0', '2023-01-18', '16:53:43', '17:13:19', 'Arrived late and Left early', 0),
(39, 928917125, 'Piyush Shinde', 0, '56', '0', '2023-02-01', '09:12:11', '09:12:43', 'Arrived on time and Left early', 0),
(40, 928917125, 'Piyush Shinde', 0, '56', '0', '2023-02-08', '13:26:35', '13:39:31', 'Arrived late and Left early', 0),
(41, 928917125, 'Piyush Shinde', NULL, 'IT', 'Bank', '2023-04-04', '12:17:50', '12:18:43', 'Arrived late and Left early', 0),
(42, 1084640127, 'Shital Rahane', 49, 'IT', 'Home', '2023-04-05', '17:17:25', NULL, 'Arrived late', 0),
(43, 14011844127, 'Kiran Lungade', 39, 'IT', 'Home', '2023-04-05', '17:21:25', '17:22:35', 'Arrived late', 0),
(44, 928917125, 'Piyush Shinde', 56, 'IT', 'Sick', '2023-04-05', '17:30:11', '17:45:20', 'Arrived late', 0),
(45, 25210948127, 'Shreyas Bhor', 7, 'IT', 'Sick', '2023-04-06', '16:27:28', NULL, 'Arrived late', 0),
(46, 928917125, 'Piyush Shinde', 56, 'IT', 'Bank', '2023-04-06', '17:10:31', '17:11:04', 'Arrived late and Left early', 0),
(47, 928917125, 'Piyush Shinde', 56, 'IT', 'Home', '2023-04-08', '15:51:23', '16:00:00', 'Arrived late', 0),
(48, 9220967127, 'Arati Rahane', 47, 'IT', 'Sick', '2023-04-08', '15:53:02', NULL, 'Arrived late', 0),
(49, 928917125, 'Piyush Shinde', 56, 'IT', 'Bank', '2023-04-12', '16:21:32', '16:31:49', 'Approved late and Reached early', 0),
(50, 14011844127, 'Kiran Lungade', 39, 'IT', 'Home', '2023-04-12', '16:24:27', '16:32:02', 'Approved late and Reached early', 0),
(52, 14011844127, 'Kiran Lungade', 39, 'IT', 'Bank', '2023-04-13', '17:25:02', '17:25:20', 'Approved and Reached', 0);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `name` text NOT NULL,
  `Department` varchar(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`name`, `Department`, `username`, `password`) VALUES
('', '', '', ''),
('Admin1', 'IT', 'Admin1', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `registration1`
--

CREATE TABLE `registration1` (
  `name` text NOT NULL,
  `Department` varchar(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration1`
--

INSERT INTO `registration1` (`name`, `Department`, `username`, `password`) VALUES
('', '', '', ''),
('staff', 'IT', 'staff', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `registration2`
--

CREATE TABLE `registration2` (
  `name` text NOT NULL,
  `Department` varchar(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration2`
--

INSERT INTO `registration2` (`name`, `Department`, `username`, `password`) VALUES
('', '', '', ''),
('Hod', 'IT', 'Hod', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `registration3`
--

CREATE TABLE `registration3` (
  `name` text NOT NULL,
  `Department` varchar(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration3`
--

INSERT INTO `registration3` (`name`, `Department`, `username`, `password`) VALUES
('', '', '', ''),
('Admin2', 'IT', 'Admin2', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `SerialNumber` int(11) DEFAULT NULL,
  `Department` varchar(30) DEFAULT NULL,
  `CardID` double NOT NULL,
  `Reason` varchar(50) DEFAULT NULL,
  `CardID_select` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `SerialNumber`, `Department`, `CardID`,`Personal`, `Reason`, `CardID_select`) VALUES
(1, 'Prof. Nikam ', 102, 'IT', 42435519, NULL, 0),
(2, 'Prof. Gawali', 101, 'IT', 1221013873, NULL, 0),
(3, 'Arati Rahane', 47, 'IT', 9220967127, 'Bank', 0),
(4, 'Kishor More', 40, 'IT', 25221250127, NULL, 0),
(5, 'Pramila Shinde', 57, 'Computer', 762533125, NULL, 0),
(6, 'Ishwar Wagh', 66, 'Computer', 18814114125, NULL, 0),
(7, 'Viraj Adhav', 1, 'IT', 10857250123, NULL, 0),
(8, 'Dipjyot jape', 30, 'IT', 442399125, '', 0),
(9, 'Vaishavi Dhavade', 20, 'Computer', 23613252127, NULL, 0),
(10, 'Arati Walte', 68, 'Computer', 12415613125, NULL, 0),
(11, 'Jayavant Warkhade', 69, 'Computer', 10823810125, NULL, 0),
(12, 'tejas sonawane', 61, 'IT', 10812311125, NULL, 0),
(13, 'Vaibhav Lokhande', 38, 'Computer', 765610125, NULL, 0),
(14, 'Tejas Nagare', 41, 'IT', 281938125, NULL, 0),
(15, 'Vaishnavi Aher', 65, 'Computer', 20412311125, 'Demo', 0),
(16, 'Shubham Kamandar', 32, 'IT', 1402208125, '', 0),
(17, 'Saurabh Hon', 24, 'IT', 204910124, NULL, 0),
(18, 'Piyush Shinde', 56, 'IT', 928917125, 'Home', 0),
(19, 'Shital Rahane', 49, 'IT', 1084640127, 'Home', 0),
(20, 'Shreyas Bhor', 7, 'IT', 25210948127, 'Sick', 0),
(21, 'Chetan Barde', 75, 'IT', 1721361125, NULL, 0),
(22, 'Shekhar Bhide', 5, 'IT', 6017945127, NULL, 0),
(23, 'Sachin Sadgir', 51, 'IT', 7623541127, NULL, 0),
(24, 'Kiran Lungade', 39, 'IT', 14011844127, 'Bank', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approval`
--
ALTER TABLE `approval`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `registration1`
--
ALTER TABLE `registration1`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `registration2`
--
ALTER TABLE `registration2`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `registration3`
--
ALTER TABLE `registration3`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approval`
--
ALTER TABLE `approval`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
