
<?php
    include 'connectDB.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Details</title>
    
    <style type="text/css">
body {background-image:url("image/sanjivani.jpg");background-repeat:no-repeat;background-attachment:fixed;
    background-position: top right;
    background-size: cover;}
header .head h1 {font-family:aguafina-script;text-align: center;color:#black;}
header .head img {float: left;}
header a {float: right;text-decoration: none;font-family:cursive;font-size:25px;color:red;margin:-60px 0px 0px 20px;padding-right: 100px}
a:hover {opacity: 0.8;cursor: pointer;}
.bod {background-color:#ddd; opacity: 0.7;border-collapse: collapse;width:100%;height:230px;padding-bottom:20px}
.opt {float: left;margin: 20px 80px 0px 20px;}
.opt input {padding:4px 0px 2px 6px;margin:4px;border-radius:10px;background-color:#ddd; color: black;font-size:16px;border-color: black}
.opt p {font-family:cursive;text-align: left;font-size:19px;color:#f2f2f2;}
.opt label {color:black;font-size:23px}
.opt label:hover {color:red;opacity: 0.8;cursor: pointer;}
.opt table tr td {font-family:cursive;font-size:19px;color:black;}
.opt #lo {padding:4px 8px;margin-left:28px;background-color:#00A8A9;border-radius:7px;font-size:15px}
.opt #up {padding:4px 8px;margin-left:28px;background-color:#00A8A9;border-radius:7px;font-size:15px}
#lo:hover{opacity: 0.8;cursor: pointer;background-color:red}
#up:hover{opacity: 0.8;cursor: pointer;background-color:green}

.car {font-family:cursive;font-size:19px;padding-top: 45px;margin: 10px}

.op input {border-radius:10px;background-color:#ddd; color: black;font-size:16px;padding-left:5px;margin:18px 0px 0px 10px;border-color: black}
.op button {margin:7px 0px 5px 82px}
.op button:hover {cursor: pointer;}

#table {font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;border-collapse: collapse;width:      100%;}
#table td, #table th {border: 1px solid #ddd;padding: 8px;opacity: 0.6;}
#table tr:nth-child(even){background-color: #f2f2f2;}
#table tr:nth-child(odd){background-color: #f2f2f2;opacity: 0.9;}
#table tr:hover {background-color: #ddd; opacity: 0.8;}
#table th {opacity: 0.6;padding-top: 12px;padding-bottom: 12px;text-align: left;background-color:         #00A8A9;color: white;}
   
</style>

</head>

<body>
<header >
    
    <div class="head">
    <img src="image/icon1.png" width="110" height="90">
      <h1>RFID<br>
      Reason For Gate Pass</h1>
    </div>
  </header>

<TABLE id='table'>

    <?php
        $data=$_GET['data'];
        $sql= "SELECT * FROM `users` WHERE id=$data";
        $result=mysqli_query($conn,$sql);
        if($result)
        {
            $row=mysqli_num_rows($result);
            {
                echo '<thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Number</th>
                    <th>Department</th>
                    <th>CardID</th>
                    <th>Reason Type</th>
                    <th>Reason</th>
                </tr>
                </thead>
                ';
                $row=mysqli_fetch_assoc($result);
                {
                    echo '<tbody>
                    <tr>
                        <td>'.$row['id'].'</td>
                        <td>'.$row['username'].'</td>
                        <td>'.$row['SerialNumber'].'</td>
                        <td>'.$row['Department'].'</td>
                        <td>'.$row['CardID'].'</td>
                        <td>'.$row['Personal'].'</td>
                        <td>'.$row['Reason'].'</td>    
                    </tr>
                    </tbody>';    
                }
            }        
        }
    ?>
    <div class="bod">
    <div class="opt">
    <form method = "post" >            
                <label style="color:black" for = "Reason_Value"><h2> Enter Reason:</h2></label>
                <input type="text" placeholder="Write a reason..." id="Reason_Value" name="Reason_Value"><br><br>
                <label for="personal"><input type="radio" id="Official Leave" name="Personal" value="Official"> Official</label>
                <label for="non-personal"><input type="radio" id="Non-Official Leave" name="Personal" value="Non-Official"> Non-Official</label><br><br>
                <input type="submit" name ="submit" value="Save" id="up"><br><br>
    </form>
    </div></div>
        <?php
        error_reporting(0);
        
        if (isset($_POST['submit']))
        {
            echo '<script>window.location.href = window.location.href;</script>';
            $NEW_REASON_VALUE = $_POST['Reason_Value'];
            $personal = $_POST['Personal'];
            $sql = "UPDATE users SET Reason = '$NEW_REASON_VALUE', Personal = '$personal' WHERE id = $data";
            if (mysqli_query($conn,$sql))
            {
                
                // echo "Updated";
                

                $row = mysqli_fetch_assoc($result);
        ?>
            <TR>
            <TD><?php echo $row['id'];?></TD>
            <TD><?php echo $row['username'];?></TD>
            <TD><?php echo $row['SerialNumber'];?></TD>
            <TD><?php echo $row['Department'];?></TD>
            <TD><?php echo $row['CardID'];?></TD>
            <TD><?php echo $row['Personal'];?></TD>
            <TD><?php echo $row['Reason'];?></TD>
            </TR>
    <!-- () -->
        <?php
            }
            else 
            {
                echo "Not Updated";
            }
        }


?>
</TABLE>

<TABLE id='table'>

    <?php
        $data=$_GET['data'];
        $sql_q= "SELECT * FROM `users` WHERE id=$data";
        $res=mysqli_query($conn,$sql_q);
        if($res)
        {
            $row=mysqli_num_rows($res);
            {
                $row=mysqli_fetch_assoc($res);
            }        
        }
    ?>
        <?php
        error_reporting(0);
        
        if (isset($_POST['submit']))
        {
            header("Refresh:0");

            $sql_q = "INSERT INTO approval (username,SerialNumber,Department,CardID,Personal,Reason) SELECT username,SerialNumber,Department,CardID,Personal,Reason FROM users WHERE id = $data";
            if (mysqli_query($conn,$sql_q))
            {
                // echo "Updated";
                $row = mysqli_fetch_assoc($res);
            }
            else 
            {
                echo "Not Updated";
            }
        }


?>
</TABLE>

    <div class="opt">        
            <a href="search.php">
                        <button type="submit" name="set" style="border:none;background: none;" title="Select">
                        <img src="image/back.png" height="60" width="50" >
                    </button>
            </a>
    </div>
    <!-- <div class="opt">
        
        <form  action = "approval.php" method = "post" >   
        <button type="submit" name="set" style="border:none;background: none;" title="Select">
            <input type="submit" name ="sub" value="Submit" id="up">
        </form>
        </div> -->
</body>
</html>