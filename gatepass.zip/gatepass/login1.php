<html>  
    <head>  
        <title>login system for Staff</title>  
      
        <!-- <link rel = "stylesheet" type = "text/css" href = "login.css">    -->

<style type="text/css">
body {
    background-image:url("image/sanjivani.jpg");
    background-repeat:no-repeat;background-attachment:fixed;
    background-position: top right;background-size: cover;
    height: 85vh;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: sans-serif;
}  
.Abc{ 
    background-color:#ddd; 
    opacity: 0.8;
    display: flex;
    align-items: center;
    flex-direction: column;
    height: 57vh;
    width: 50vh;
    border: 5px solid gray;
    border-radius: 12px;
    text-align: center;
    margin-top: 10%;
    box-shadow: 10px 12px 20px gray;
    padding-bottom: 10px;
}
header {
    height: 1px;
    padding-top: 0px;
    padding-bottom: 85px;
    font-size: 28px;
    font-weight: 700;
    color: navy;
    font-family: 'Times New Roman', Times, serif;
}
/* h1{
    color: black;
    /* padding: 1px; */
    /* font-family: 'Times New Roman', Times, serif;
    font-size: 55px;*/
h2{
    padding: 7px;
    padding-bottom: 0%;
    font-family: 'Times New Roman';
    font-size:30px;
	color: black;
}
.info{
    text-align: center;
    text-transform: capitalize;
    margin: 40px;
}
.info-1{
    text-align: center;
    text-transform: capitalize;
}
label{
    text-transform: capitalize;
    font-size: 22px;
    color: rgb(255, 255, 0);
}
.image img{
    filter: blur(100%);
}
input{
    text-align: center;
    text-transform: capitalize;
    border: 2px solid black;
    border-radius: 35px;
    height: 45px;
    width: 280px;
    font-size: 20px;
    font-family: cursive;
    background-color: whitesmoke;
    color: solid black;
    margin-top: 5%;
    
}
input:hover{
    background-color: #b4e072;
    color: #12026d;
    transform: scale(1.18);
    transition: transform 200ms ease-in;
}
button{
        margin-top: 7%;
        display: block;
        width: 100%;
        padding: 10px;
        border: 0;
        color: #fff;
        border-radius: 20px;
        cursor: pointer;
        font-size: 20px;
        font-family: cursive;
        background: rgb(252,205,128);
        background: linear-gradient(90deg, rgba(252,205,128,1) 0%, rgba(209,122,142,1) 55%, rgba(220,159,174,1) 100%); 
        
    }
    button:focus{
        outline: 0;
    }
    button:hover{
        opacity: 0.8;
        transition: .3s;
    }  
</style>
</head>  
<body scroll="no" style="overflow : hidden"> 
<section>
	<Center> 
        <header>
            <h1>Sanjivani College Of Engineering <br>
            Get Pass System</h1>  
        </header>
        
        <div class = " Abc">
        <h2><u><center>Staff LOGIN</center></u></h2> 
               <hr>   
            <form name="f1" action = "authentication1.php" onsubmit = "return validation()" method = "POST">  
                
                <input type = "text" id ="user" name  = "user" placeholder="Username" />  
                <br/><br/>
                
                    <input type = "password" id ="pass" name  = "pass" placeholder="Password"/>  
                    <br/><br/> 
                    
                    <button type =  "submit" id = "btn"/>Login</button>  
                    <!-- <a href ="register.php"><button type =  "button" id = "btn"/>Register</button>  -->
    
            </form>  
        </div> 
        <div class="image">
            <img src="url("image/sanjivani.jpg")" alt="">
        </div>
        <script>  
                function validation()  
                {  
                    var id=document.f1.user.value;  
                    var ps=document.f1.pass.value;  
                    if(id.length=="" && ps.length=="") {  
                        alert("User Name and Password fields are empty");  
                        return false;  
                    }  
                    else  
                    {  
                        if(id.length=="") {  
                            alert("User Name is empty");  
                            return false;  
                        }   
                        if (ps.length=="") {  
                        alert("Password field is empty");  
                        return false;  
                        }  
                    }                             
                }  
        </script>  
	</Center>
	</section>
</body>     
</html>  