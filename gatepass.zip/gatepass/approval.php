<?php
    if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] ==='on')
    {
        $url="https://";
    }
    else{
        $url="http://";
        $url.=$_SERVER['HTTP_HOST'];
        $url.=$_SERVER['REQUEST_URI'];
        $url;
    }
    $page= $url;
    $sec=5;

    include 'connectDB.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="refresh" content="<?php echo $sec; ?>" URL="<?php echo $page; ?>">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aproval</title>

    <style type="text/css">
body {background-image:url("image/sanjivani.jpg");background-repeat:no-repeat;background-attachment:fixed;
    background-position: top right;
    background-size: cover;}
header .head h1 {font-family:aguafina-script;text-align: center;color:#black;}
header .head img {float: left;}
header a {float: right;text-decoration: none;font-family:cursive;font-size:25px;color:red;margin:-60px 0px 0px 20px;padding-right: 100px}
a:hover {opacity: 0.8;cursor: pointer;}
.bod {background-color:#ddd; opacity: 0.7;border-collapse: collapse;width:100%;height:170px;padding-bottom:20px}
.opt {float: left;margin: 20px 80px 0px 20px;}
.opt input {padding:4px 0px 2px 6px;margin:4px;border-radius:10px;background-color:#ddd; color: black;font-size:16px;border-color: black}
.opt p {font-family:cursive;text-align: left;font-size:19px;color:#f2f2f2;}
.opt label {color:black;font-size:23px}
.opt label:hover {color:red;opacity: 0.8;cursor: pointer;}
.opt table tr td {font-family:cursive;font-size:19px;color:black;}
.opt #lo {padding:4px 8px;margin-left:28px;background-color:#00A8A9;border-radius:7px;font-size:15px}
.opt #up {padding:4px 8px;margin-left:28px;background-color:#00A8A9;border-radius:7px;font-size:15px}
#lo:hover{opacity: 0.8;cursor: pointer;background-color:red}
#up:hover{opacity: 0.8;cursor: pointer;background-color:green}

.car {font-family:cursive;font-size:19px;padding-top: 45px;margin: 10px}

.op input {border-radius:10px;background-color:#ddd; color: black;font-size:16px;padding-left:5px;margin:18px 0px 0px 10px;border-color: black}
.op button {margin:7px 0px 5px 82px}
.op button:hover {cursor: pointer;}

#table {font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;border-collapse: collapse;width:      100%;}
#table td, #table th {border: 1px solid #ddd;padding: 8px;opacity: 0.6;}
#table tr:nth-child(even){background-color: #f2f2f2;}
#table tr:nth-child(odd){background-color: #f2f2f2;opacity: 0.9;}
#table tr:hover {background-color: #ddd; opacity: 0.8;}
#table th {opacity: 0.6;padding-top: 12px;padding-bottom: 12px;text-align: left;background-color:         #00A8A9;color: white;}
   
</style>
</head>
<body>
    
    <header >
        <div class="head">
        <img src="image/icon1.png" width="110" height="90">
            <h1>RFID<br>
            List of Pending Approval For Gate Pass</h1>
        </div>
        <a href="Landing.php">
                        <button type="submit" name="set" style="border:none;background: none;" title="Select">
                        <img src="image/log.jpg" height="60" width="100" >
                    </button>
            </a>

        <!-- <div class="opt">
		<table border="0">
			<tr>
				<td><p>Select the date log:
				<form method="POST" action="">
					<input type="date" name="date"><br>
					<input type="submit" name="seldate" value="Select Date" id="inp">
				</form>
				</p></td>
			</tr>
		</table>
	</div> -->
    </header>

    <TABLE id='table'>
    <?php
        error_reporting(0);
        $sql= "SELECT * FROM `approval` WHERE Approval='Requested'";
        $result=mysqli_query($conn,$sql);
        if($result>0)
        {
            $row=mysqli_num_rows($result);
            {
                echo '<thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Department</th>
                    
                    <th>Date</th>
                    <th>Reason Type</th>
                    <th>Approval</th>
                </tr>
                </thead>
                ';
                while($row=mysqli_fetch_assoc($result))
                {
                    echo '<tbody>
                    <tr>
                        <td>'.$row['id'].'</td>
                        <td>'.$row['username'].'</td>
                        <td>'.$row['Department'].'</td>
                        
                        <td>'.$row['Date'].'</td>
                        <td>'.$row['Personal'].'</td>
                        <td><a href="grant.php?data='.$row['id'].'">'.$row['Approval'].'</td>   
                    </tr>
                    </tbody>';    
                }
            }        
        }   
    ?>
    <!-- <div class="bod">
    <div class="opt">
    <form method = "post" >            
                <label style="color:black" for = "Approval_Value"><h2> Approval:</h2></label>
                <input type="radio" name="Approval_Value" value="Approved" required /><label >Approve</label >
                <input type="radio" name="Approval_Value" value="Rejected" required /><label>Reject</label >
                <input type="submit" name ="submit" value="Submit" id="up">
    </form>
    </div></div> -->
        <?php
        // error_reporting(0);
        
        // if (isset($_POST['submit']))
        // {
        //     header("Refresh:0");

        //     $NEW_APPROVAL_VALUE = $_POST['Approval_Value'];
        //     $sql = "UPDATE approval SET Approval = '$NEW_APPROVAL_VALUE' WHERE Approval='Requested'";
        //     if (mysqli_query($conn,$sql))
        //     {
        //         echo "Updated";

        //         $row = mysqli_fetch_assoc($result);
        ?>
            <!-- <TR>
            <TD><?php echo $row['id'];?></TD>
            <TD><?php echo $row['username'];?></TD>
            <TD><?php echo $row['Department'];?></TD>
            <TD><?php echo $row['CardID'];?></TD>
            <TD><?php echo $row['Date'];?></TD>
            <TD><?php echo $row['Personal'];?></TD>
            <TD><?php echo $row['Reason'];?></TD>
            <TD><?php echo $row['Approval'];?></TD>
            </TR> -->
        <?php
        //     }
        //     else 
        //     {
        //         echo "Not Updated";
        //     }
        // }


?>

    </TABLE>
<div class="opt">
    <form  action = "report.php" method = "post" >   
        <button type="submit" name="set" style="border:none;background: none;" title="Select">
            <input type="submit" name ="sub" value="Individual Report" id="up">
        </form>
        </div>
</body>
</html>