<?php
    include 'connectDB.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search</title>

    <style type="text/css">
body {background-image:url("image/sanjivani.jpg");background-repeat:no-repeat;background-attachment:fixed;
    background-position: top right;
    background-size: cover;}
header .head h1 {font-family:aguafina-script;text-align: center;color:#black;}
header .head img {float: left;}
header a {float: right;text-decoration: none;font-family:cursive;font-size:25px;color:red;margin:-60px 0px 0px 20px;padding-right: 100px}
a:hover {opacity: 0.8;cursor: pointer;}
.bod {
    
    background-color:#ddd; opacity: 0.7;border-collapse: collapse;width:100%;height:80px;padding-bottom:20px}
.opt 
{
    display:flex;
    text-align:center;
    justify-content:center;
    margin:5%;
   /* float: left;*/
    /*margin: 20px 80px 0px 20px;*/
}
.opt input {padding:4px 0px 2px 106px;margin:7px;border-radius:10px;background-color:#ddd; color: black;font-size:16px;border-color: black}
.opt p {font-family:cursive;text-align: center;font-size:19px;color:#f2f2f2;margin-left:10%;}
.opt label {color:black;font-size:23px}
.opt label:hover {color:red;opacity: 0.8;cursor: pointer;}
.opt table tr td {font-family:cursive;font-size:19px;color:black;}
.opt #lo {padding:4px 8px;margin-left:25px;background-color:#00A8A9;border-radius:7px;font-size:15px}
.opt #up {
    
    padding: 5px 8px;
   
    background-color: #00A8A9;
    border-radius: 7px;
    font-size: 15px;
    margin-top: 5px;
    margin-left: 6%;}
#lo:hover{opacity: 0.8;cursor: pointer;background-color:red}
#up:hover{opacity: 0.8;cursor: pointer;background-color:green}

.car {font-family:cursive;font-size:19px;padding-top: 45px;margin: 10px}

.op input {border-radius:10px;background-color:#ddd; color: black;font-size:16px;padding-left:35px;margin:18px 0px 0px 10px;border-color: black}
.op button {margin:7px 0px 5px 82px}
.op button:hover {cursor: pointer;}

#table {font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;border-collapse: collapse;width:      100%;}
#table td, #table th {border: 1px solid #ddd;padding: 8px;opacity: 0.6;}
#table tr:nth-child(even){background-color: #f2f2f2;}
#table tr:nth-child(odd){background-color: #f2f2f2;opacity: 0.9;}
#table tr:hover {background-color: #ddd; opacity: 0.8;}
#table th {opacity: 0.6;padding-top: 12px;padding-bottom: 12px;text-align: left;background-color:         #00A8A9;color: white;}
   
</style>
</head>
<body>

    <header >
        <div class="head">
        <img src="image/icon1.png" width="110" height="90">
        <h1>Sanjivani College of Engineering, Kopargaon<br>
        Search For Gate Pass</h1>
        </div>
        <a href="Landing.php">
                        <button type="submit" name="set" style="border:none;background: none;" title="Select">
                        <img src="image/log.jpg" height="60" width="100" >
                    </button>
            </a>
    </header>
    
    
    <div class="container my-5">
    
        <div class="bod">
        <center>
            <div class="opt">
                <form method="post">
                    <input type="text" placeholder="Search" name="search"><br>
                    <button class="btn btn-dark btn-sm" name="submit" id="up">Search</button>
                </form>

        </div><center>
</div>
        <div class="container my-5">
            <TABLE id='table'>
            
                <?php
                
                    if(isset($_POST['submit']))
                    {
                        error_reporting(E_ERROR | E_PARSE);
                        $search=$_POST['search'];
                        $sql="SELECT * FROM `users` WHERE id like '%$search%' or username like '%$search%' or SerialNumber like '%$search%' or Department like '%$search%'";
                        $result=mysqli_query($conn,$sql);
                        if($result)
                        {
                            if(mysqli_num_rows($result) > 0){
                                echo '<thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Emp_ID</th>
                                    <th>Department</th>
                                    <th>CardID</th>
                                </tr>
                                </thead>
                                ';
                                while($row=mysqli_fetch_assoc($result))
                                {
                                    echo '<tbody>
                                    <tr>
                                        <td><a href="searchdata.php?data='.$row['id'].'">'.$row['id'].'</a></td>
                                        <td>'.$row['username'].'</td>
                                        <td>'.$row['SerialNumber'].'</td>
                                        <td>'.$row['Department'].'</td>
                                        <td>'.$row['CardID'].'</td>
                                    </tr>
                                    </tbody>';
                                }
                            }
                            else{
                                echo '<h2 class=text-danger>Data not found</h2>';
                            }
                        }
                    }
                    
                ?>


                </TABLE>
        </div>
    </div>
    <div>
            
    </div>
</body>
</html>