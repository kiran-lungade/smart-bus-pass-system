<!DOCTYPE html>
<html>
<head>
	<title>Leave Report</title>
	<style type="text/css">
		
		body {background-image:url("image/sanjivani.jpg");background-repeat:no-repeat;background-attachment:fixed;
	  		background-position: top right;
	  		background-size: cover;}
			.bod {background-color:#ddd; opacity: 0.7;text-align: center;border-collapse: collapse;width:50%;height:200px;padding-top:10px;padding-bottom:10px}
.opt {float: center;margin: 20px 80px 0px 20px;}
.opt input {padding:4px 0px 2px 6px;margin:4px;border-radius:10px;background-color:#ddd; color: black;font-size:16px;border-color: black}
.opt p {font-family:cursive;text-align: center;font-size:19px;color:black;}
.opt label {color:black;font-size:23px}
.opt label:hover {color:red;opacity: 0.8;cursor: pointer;}
.opt table tr td {font-family:cursive;font-size:19px;color:black;}
.opt #lo {padding:4px 8px;margin-left:28px;background-color:#00A8A9;border-radius:7px;font-size:15px}
.opt #up {padding:4px 8px;margin-left:28px;background-color:#00A8A9;border-radius:7px;font-size:15px}

		body {
			font-family: Arial, sans-serif;
			background-color: #f2f2f2;
		}

		h1 {
			color: #444;
			text-align: center;
			margin-top: 30px;
			margin-bottom: 30px;
		}

		form {
			background-color: #fff;
			padding: 20px;
			margin: 0 auto;
			max-width: 500px;
			border-radius: 5px;
			box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
		}

		label {
			display: block;
			margin-bottom: 10px;
			font-size: 16px;
			color: #444;
		}

		input[type="text"],
		input[type="month"],
		input[type="submit"] {
			display: block;
			width: 100%;
			padding: 10px;
			font-size: 16px;
			border-radius: 5px;
			border: none;
			margin-top:20px;
			margin-bottom: 20px;
		}

		input[type="submit"] {
			background-color: #4CAF50;
			color: #fff;
			cursor: pointer;
		}

		input[type="submit"]:hover {
			background-color: #3e8e41;
		}

		table {
			border-collapse: collapse;
			margin-top: 30px;
			margin-bottom: 30px;
			margin-left: auto;
			margin-right: auto;
			border-radius: 5px;
			box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
		}

		th, td {
			padding: 10px;
			border: 1px solid black;
			text-align: center;
		}

		th {
			background-color: #4CAF50;
			color: #fff;
		}

		h2 {
			color: #444;
			text-align: center;
			margin-top: 30px;
			margin-bottom: 30px;
		}
	</style>
</head>
<body>
	<h1>Leave Report</h1>
	<form method="post">
		<label for="Name">Employee Name:</label>
		<input type="text" id="Name" name="Name">
		<label for="month">Select Date</label>
		From<input type="date" id="date1" name="date1">
		To<input type="date" id="date2" name="date2">
		<input type="submit" value="Generate Report">
	</form><br><br>
	<form>
	<?php
	error_reporting(0);
	// Check if form is submitted
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		// Get inputs from the form
		$Name = $_POST['Name'];
		$date1 = $_POST['date1'];
		$date2= $_POST['date2'];
		// Connect to the database
		include('connectDB.php'); 

		// Check connection
		if (mysqli_connect_errno()) {
			die('Failed to connect to MySQL: ' . mysqli_connect_error());
		}

		// Query the database
		//$query = "SELECT COUNT(*) as leave_count, SEC_TO_TIME(SUM(TIME_TO_SEC(TIMEDIFF(TimeIn, TimeOut)))) as total_hours FROM logs WHERE Name='$Name' AND MONTH(DateLog)=MONTH('$month')";
		$query = "SELECT COUNT(*) as leave_count FROM logs WHERE Name like '%$Name%'  AND DateLog>='$date1' AND DateLog<='$date2'";
		$query1= "SELECT * from logs WHERE Name like '%$Name%' AND Personal= 'Official' AND DateLog>='$date1' AND DateLog<='$date2'";
		$query2= "SELECT * from logs WHERE Name like '%$Name%' AND Personal= 'Non-Official' AND DateLog>='$date1' AND DateLog<='$date2'";
		$result1 = mysqli_query($conn, $query1);
		$result2 = mysqli_query($conn, $query2);
		if ($result1) {
			$sum1=0;
			while($row1 = mysqli_fetch_assoc($result1))
			{
				
			$T11 = $row1['TimeIn'];
			$T21 = $row1['TimeOut'];
			// echo $T1;
		    // echo $T2;
			$time11=strtotime($T11);
			$time21=strtotime($T21);
			$td1=abs($time21-$time11);
			$hrs1=floor($td1/3600);
			$min1=floor(($td1-($hrs1 * 3600))/60);
			$sec1=$td1-($hrs1*3600)-($min1*60);
			$TD1=sprintf('%02d:%02d:%02d',$hrs1,$min1,$sec1);
			
			
			$sum1 += $td1;

			// echo "<br>";
			// echo $TD;
			// echo "<br>";
		}
		$sum_hrs1 = floor($sum1 / 3600);
		$sum_min1 = floor(($sum1 - ($sum_hrs1 * 3600)) /60);		
		}
		if ($result2) {
			$sum2=0;
			while($row2 = mysqli_fetch_assoc($result2))
			{
				
			$T12 = $row2['TimeIn'];
			$T22 = $row2['TimeOut'];
			// echo $T1;
		    // echo $T2;
			$time12=strtotime($T12);
			$time22=strtotime($T22);
			$td2=abs($time22-$time12);
			$hrs2=floor($td2/3600);
			$min2=floor(($td2-($hrs2 * 3600))/60);
			$sec2=$td2-($hrs2*3600)-($min2*60);
			$TD2=sprintf('%02d:%02d:%02d',$hrs2,$min2,$sec2);
			
			
			$sum2 += $td2;

			// echo "<br>";
			// echo $TD;
			// echo "<br>";
		}
		$sum_hrs2 = floor($sum2 / 3600);
		$sum_min2 = floor(($sum2 - ($sum_hrs2 * 3600)) /60);		
		}
		
	
		$result = mysqli_query($conn, $query);
		if ($result) {
			$row = mysqli_fetch_assoc($result);
			$leave_count = $row['leave_count'];
			//$total_hours = $row['total_hours'];
			?>
			<!-- // Display the report -->
			<center>
				<?php
			echo "<h2>$Name's Leave Report from $date1 To $date2 </h2>";
			echo "<table>";
			echo "<tr><th>Leave Count</th><th>Total Official Time</th><th>Total Non-Official Time/th></tr>";
			echo "<tr><td>$leave_count</td><td>$sum_hrs1 hr:$sum_min1 min</td><td>$sum_hrs2 hr:$sum_min2 min</td></tr>";
			echo "</table>";
			?>
			</center>
			<?php
		} else {
			echo "Error: " . mysqli_error($conn);
		}
		
		// Close the database connection
		mysqli_close($conn);
	}
	?>
	</form>
</body>
</html>
